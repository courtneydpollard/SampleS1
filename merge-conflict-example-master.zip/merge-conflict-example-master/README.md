# merge-conflict-example
Example repo for learning how to resolve merge conflicts
